<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_customadv
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
JHtml::_('jquery.framework');
if($params->get('scriptradio', 1) or $params->get('cssradio', 1))
{
	$document = JFactory::getDocument();
	if ($params->get('modulscript')) {
	$document->addScript($params->def('modulscript'));
	}
	if ($params->get('modulscript2')) {
		$document->addScript($params->def('modulscript2'));
	}
	if ($params->get('modulscript3')) {
		$document->addScriptDeclaration($params->def('modulscript3'));
	}
	if($params->get('cssradio', 1)){
	$document->addStyleSheet($params->def('modulcss'));
	}
}
if ($params->def('prepare_content', 1))
{
	JPluginHelper::importPlugin('content');
	$module->content = JHtml::_('content.prepare', $module->content, '', 'mod_customadv.content');
}

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'), ENT_COMPAT, 'UTF-8');

require JModuleHelper::getLayoutPath('mod_customadv', $params->get('layout', 'default'));
